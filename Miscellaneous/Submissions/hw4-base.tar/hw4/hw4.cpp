#include "lib.h"
#include "objects.h"
#include "shapes.h"
#include "vector4d.h"
#include "scene.h"
#include <cmath>

namespace display {
    // Basic Variables
    int axes = 1; // Toggle axis display
    int depth = 0; // Depth test
    int th = 0; // Azimuth of view angle
    int ph = 0; // Elevation of view angle
    int light = 1; // Toggle lighting
    double asp = 1; // Aspect ratio
    double dim = 1.0; // Size of world
    int innerWidth = 800; // Window Width
    int innerHeight = 600; // Window Height

    // Camera Variables
    double cameraSpeed = 1; // Camera rotation speed
    double cameraFirstPersonSpeedModifier = 0.9; // First-person camera speed modifier
    double cameraDistance = 5; // 11 by default
    std::string projMode = "perspective";
    Vector4d cameraPosition(0, 5, 25);
    Vector4d cameraForward(0, 0, -1);
    Vector4d cameraRight(1, 0, 0);

    // Light Variables
    int alpha = 100; // Transparency
    int emission = 0; // Emission intensity (%)
    int ambient = 0; // Ambient intensity (%)
    int diffuse = 100; // Diffuse intensity (%)
    int specular = 0; // Specular intesity (%)
    int shininess = 0; // Shininess (Power of Two)
    float shiny = 1; // Shininess (value)
    int zh = 90; // Light Azimuth
    float yLight = 0; // Elevation of Light

    // FPS Variables
    int fpstime = 0;
    int timebase = 0;
    int frame = 0;
    int fps = 0;
}

using namespace display;

// Reset Camera

// Project

// Enable Lighting

// Set Camera

// Key Update

// Key Up

// Key Down

// Special Up

// Special Down

// Reshape

// Draw Axes

// Display/Draw

// Loop
