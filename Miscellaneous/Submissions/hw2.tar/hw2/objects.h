#pragma once

#include "lib.h"

void drawScene();
void airplane(const std::string& color);
void turret(Vector3d& orientation);