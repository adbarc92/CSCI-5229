void fullCylinder(const std::string& texture, double yPos){
  Texture& tex = getTexture(texture);
  tex.bind();

  double angle = normalize(1, 0, granularity, 0, 360);
  glScaled()
  
  circle(texture);

  glBegin(GL_QUAD_STRIP);
  for (int i = 0; i <= granularity; i++) {
    double x = Cos(angle * i);
    double z = Sin(angle * i);
    glNormal3f(x, 0, z);
    glTexCoord2f((float)i / (float)granularity, 0);
    glVertex3f(x, -1, z);
    glTexCoord2f((float)i / (float)granularity, 1);
    glVertex3f(x, +1, z);
  }
  glEnd();

  tex.unbind();
}