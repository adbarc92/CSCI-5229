
void drawGrid(double length)
{
  if (grid)
  {
    int x = 0, y = 0, z = 0;
    glColor3f(1.0, 1.0, 1.0);
    glBegin(GL_LINES);
    // Grid Lines from X along Y
    for (x = 0; x < length; x++)
    {
      glVertex3d(x, 0, 0);
      glVertex3d(x, length, 0);
      glRasterPos3d(x, length, 0);
      print("(%d,%d,%d)", x, y, z);
      glVertex3d(x, 0, 0);
      glVertex3d(x, 0, length);
    }
    // Grid Lines from Y along X
    for (y = 0; y < length; y++)
    {
      glVertex3d(0, y, 0);
      glVertex3d(length, y, 0);
      glRasterPos3d(x, length, 0);
      print("(%d,%d,%d)", x, y, z);
      glVertex3d(0, y, 0);
      glVertex3d(0, y, length);
    }
    for (z = 0; z < length; z++)
    {
      glVertex3d(0, 0, z);
      glVertex3d(length, 0, z);
      glRasterPos3d(length, 0, z);
      print("(%d,%d,%d)", x, y, z);
      glVertex3d(0, 0, z);
      glVertex3d(0, length, z);
      glRasterPos3d(0, length, z);
    }
    glEnd();
  }
}